## set working directory
setwd("~/Desktop/Jiali/TAMU/PLPA689/deseq2/")

# load package DESeq2, which we already installed in week2 class.
library(DESeq2)

# prepare a sample table
## get file names
fileName <- list.files(path = "./countData/", pattern = "*.txt")
fileName
## get sample names
sampleName <- sapply(strsplit(fileName, "[.]"), "[[", 1)
sampleName
## get phenotypes
pheno <-  sapply(strsplit(fileName, "-"), "[[", 1)
pheno <- as.factor(pheno)
pheno
## build the sample table
mySampleTable <- data.frame(sampleName, fileName, pheno)
mySampleTable

## get DESeqDataSet object
myDESeqData <- DESeqDataSetFromHTSeqCount(sampleTable = mySampleTable, 
                                          directory = './countData', design = ~pheno)
myDESeqData
# Let's take a look at our dataset
head(counts(myDESeqData))

## Pre-filtering
# I usually Filter out low count data, which is not necessary to run DESeq2, but it can reduce memory usage.
dim(myDESeqData)
myDESeqData <- myDESeqData[ rowSums(counts(myDESeqData)) > 1, ]
dim(myDESeqData)

## PCA 
# Count transformation
rld <- rlog(myDESeqData, blind=FALSE)
plotPCA(rld, intgroup="pheno")

# Differential expression analysis
myDESeq <- DESeq(myDESeqData)
# although this is only one command, but it did several steps in this function. Raw counts are normalized and fitted to the negative binomial model.
# Wald test is performed here to test the statistical significance.

# Get results
myResults <- results(myDESeq, alpha=0.05, lfcThreshold = 1)
summary(myResults)
myResults

# heatmap of DEGs
library("pheatmap")
select <- which(myResults$padj <= 0.05)
df <- as.data.frame(colData(myDESeq)[,c("pheno")])
pheatmap(assay(rld)[select,], cluster_rows=TRUE, show_rownames=FALSE,
         cluster_cols=FALSE)

# MA plot
plotMA(myResults, main="lateFlower vs earlyFlower", ylim=c(-8,8))

## Output DEGs with gene functions
# Get DEGs from DESeqdata and save into a dataframe
DEGs <- as.data.frame(myResults[which(myResults$padj <= 0.05),])

# add gene functions, first load the gene annotation file
annot <- read.csv("Ppersica_298_v2.1.annotation_info.txt", header=TRUE, sep="\t", stringsAsFactors = F)
head(annot)
# One gene can have several transcripts, but we don't care about transcripts here so we keep one transcript for each gene
annot <- annot[!duplicated(annot[,2]),]
head(annot)

## add annotations as new columns to our results
DEGs_annot <- merge(DEGs, annot[,-c(1,3,4)], by.x = "row.names", by.y = "locusName", all.x = TRUE, all.y = FALSE)
## write annotated results to table
write.csv(DEGs_annot, file="DEGs.csv", row.names = F)
