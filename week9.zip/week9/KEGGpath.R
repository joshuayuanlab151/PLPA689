setwd("~/Desktop/Jiali/TAMU/PLPA689/week9/")
if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("pathview")
############## install only needs to do once #########################
library(pathview)

# same codes from DESeq2 to remove annotation duplicates
annot <- read.csv("../week8/Ppersica_298_v2.1.annotation_info.txt", header=TRUE, sep="\t", stringsAsFactors = F)
head(annot)
# One gene can have several transcripts, but we don't care about transcripts here so we keep one transcript for each gene
annot <- annot[!duplicated(annot[,2]),]
head(annot)

# extract the KEGG annotation IDs for each gene
K_hit <- annot[,c(2,9)]
# read DEGs and combined with KEGG IDs
DEgenes <- read.csv("../week8/DEGs.csv", header = T)
DEgenes <- DEgenes[,c(1,3)]
DEG_data <- merge(DEgenes, K_hit, by.x ="Row.names", by.y="locusName", all.x=T)

rownames(DEG_data) <- DEG_data$KO
# we got error saying the KEGG ids are not unique, now let's remove the duplicated IDs
data_uniq <- DEG_data[!duplicated(DEG_data$KO),]
rownames(data_uniq) <- data_uniq$KO
# turn the dataframce into matrix, exclude the KO column
data_uniq.d <- as.matrix(data_uniq[,2, drop=FALSE])

# plot pectin metabolic pathway
pv.out <- pathview(gene.data = data_uniq.d, pathway.id = "00040",
                   species = "ko", out.suffix = "ko040")
