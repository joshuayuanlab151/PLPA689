# set working directory to the folder stored this file
setwd("~/Desktop/Jiali/TAMU/PLPA689/week9")
# Install package GO plot
install.packages('GOplot') # only need to run once
# load package
library(GOplot)
library(plyr)

#---------------read AgriGO enrichment results---------------------------
sigGO <- read.table("AgriGO.txt", sep = "\t", header = T)
genes <- sigGO[,c("GO_acc","entries")]
# split the genes
genes$entries <- gsub("//",",", genes$entries)
s <- strsplit(genes$entries, split = ",")
genes <- data.frame(ID = rep(genes$GO_acc, sapply(s, length)), genes = unlist(s))
genes <- genes[!(genes$genes == ""), ]
# modify GO result table
sigGO <- sigGO[,c(1,2,3,4,9)]
colnames(sigGO) <- c("ID","category", "term", "count","adj_pval")
GOanalysis <- merge(sigGO,genes,by="ID", all=T)
# read DEGs
DEgenes <- read.csv("../week8/DEGs.csv", header = T)
DEgenes <- DEgenes[,c(1,3)]
names(DEgenes) <- c("genes","logFC")
GOanalysis <- join(GOanalysis,DEgenes, by = "genes", match="first")


# calculate z-score
for (i in 1:9628) {
  ID = GOanalysis$ID[i]
  GOterm <- GOanalysis[which(GOanalysis$ID == ID),]
  up <- sum(GOterm$logFC > 0)
  down <- sum(GOterm$logFC < 0)
  total <- length(GOterm$logFC)
  zscore <- (up-down)/total
  GOanalysis$zscore[i] <- zscore
}

GOanalysis <- GOanalysis[c("category","ID","term","count","genes","logFC","adj_pval","zscore")]
GOanalysis$category <- gsub("F","MF",GOanalysis$category)
GOanalysis$category <- gsub("P","BP",GOanalysis$category)
GOanalysis$category <- gsub("C","CC",GOanalysis$category)

# make plots
## bubble plot
GOBubble(GOanalysis, labels = 3)
GOBubble(GOanalysis, title = 'Bubble plot with background colour', display = 'multiple', bg.col = T, labels = 2, ID=F)  
## circular plot
GOcir <- GOanalysis[order(GOanalysis$adj_pval),]
pdf("DE_GO_top12.pdf", height = 8, width = 13)
GOCircle(GOcir, nsub = 12)
dev.off()
